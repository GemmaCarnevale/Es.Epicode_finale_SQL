-- 1. Verificare che i campi definiti come PK siano univoci --
SHOW COLUMNS FROM prodotto;
SHOW COLUMNS FROM regione;
SHOW COLUMNS FROM vendite;

-- 2. Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato per anno --
SELECT p.nomeProdotto AS Prodotto, YEAR(v.dataVendite) AS Anno, SUM(v.totVendite) AS Fatturato
FROM vendite v
INNER JOIN prodotto p ON v.nomeProdotto = p.nomeProdotto
GROUP BY p.nomeProdotto, YEAR(v.dataVendite)
ORDER BY p.nomeProdotto, YEAR(v.dataVendite);

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente --
SELECT vendite.idRegione AS Stato, YEAR(vendite.dataVendite) AS Anno, SUM(vendite.totVendite) AS FatturatoTotale
FROM vendite
GROUP BY vendite.idRegione, YEAR(vendite.dataVendite)
ORDER BY YEAR(vendite.dataVendite) ASC, FatturatoTotale DESC;

-- 4. Qual è la categoria di articoli maggiormente richiesta dal mercato? --
SELECT prodotto.nomeProdotto AS Prodotto, MAX(vendite.dataVendite) AS UltimaDataVendita
FROM prodotto
LEFT JOIN vendite ON prodotto.nomeProdotto = vendite.nomeProdotto
GROUP BY prodotto.nomeProdotto;

-- 5. Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti --
SELECT nomeProdotto
FROM prodotto
WHERE nomeProdotto NOT IN (SELECT DISTINCT nomeProdotto FROM vendite);

SELECT prodotto.nomeProdotto
FROM prodotto
LEFT JOIN vendite ON prodotto.nomeProdotto = vendite.nomeProdotto
WHERE vendite.nomeProdotto IS NULL;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente) --
SELECT prodotto.nomeProdotto AS Prodotto, MAX(vendite.dataVendite) AS UltimaDataVendita
FROM prodotto
LEFT JOIN vendite ON prodotto.nomeProdotto = vendite.nomeProdotto
GROUP BY prodotto.nomeProdotto;